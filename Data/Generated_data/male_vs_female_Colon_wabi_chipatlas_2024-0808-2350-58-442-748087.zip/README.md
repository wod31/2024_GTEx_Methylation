# Description of the downloaded files
  - `AnalysisID.igv.xml`: IGV session file to display DPRs or DMRs together with the original data to be compared.
    * This file must be placed in the same directory as the .igv.bed file, otherwise the DPR or DMR track cannot be properly loaded.
  - `AnalysisID.log`: Analysis log to identify DPRs or DMRs.
  - `AnalysisID.bed`: DPRs or DMRs in BED format suitable for further analysis.
  - `AnalysisID.igv.bed`: DPRs or DMRs in BED format suitable for browsing on IGV.

# Contact
  - Shinya Oki (okishinya@kumamoto-u.ac.jp)
    * Please provide the `AnalysisID` starting with "wabi_" for troubleshooting.
